import { WishlistItem, RecommendationItem } from '@/types/recommendation';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { X, Star, Film, BookOpen, Trash2, Heart, Tv, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WishlistPanelProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: WishlistItem[];
  onRemove: (itemId: string) => void;
  onItemClick: (item: RecommendationItem) => void;
}

export function WishlistPanel({ isOpen, onClose, wishlist, onRemove, onItemClick }: WishlistPanelProps) {
  return (
    <>
      {/* Overlay */}
      <div
        className={cn(
          'fixed inset-0 bg-background/80 backdrop-blur-sm z-40',
          'transition-opacity duration-300',
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        )}
        onClick={onClose}
      />

      {/* Panel */}
      <div
        className={cn(
          'fixed top-0 right-0 h-full w-full max-w-md z-50',
          'bg-card border-l border-border/50',
          'transform transition-transform duration-300 ease-out',
          isOpen ? 'translate-x-0' : 'translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Heart className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h2 className="font-serif text-xl font-bold">Your Wishlist</h2>
                <p className="text-sm text-muted-foreground">
                  {wishlist.length} {wishlist.length === 1 ? 'item' : 'items'} saved
                </p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
              <X className="w-5 h-5" />
            </Button>
          </div>

          {/* Content */}
          <ScrollArea className="flex-1 p-4">
            {wishlist.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-16 text-center">
                <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                  <Heart className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-serif text-lg font-semibold mb-2">No items yet</h3>
                <p className="text-sm text-muted-foreground max-w-[200px]">
                  Start chatting to discover movies and books you'll love!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {wishlist.map((item) => (
                  <div
                    key={item.id}
                    className={cn(
                      'group flex gap-4 p-3 rounded-xl',
                      'bg-secondary/50 hover:bg-secondary',
                      'transition-colors duration-200 cursor-pointer'
                    )}
                    onClick={() => onItemClick(item)}
                  >
                    {/* Thumbnail */}
                    <div className="w-16 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-muted relative">
                      {item.poster ? (
                        <img
                          src={item.poster}
                          alt={item.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            const placeholder = target.nextElementSibling as HTMLElement;
                            if (placeholder) placeholder.style.display = 'flex';
                          }}
                        />
                      ) : null}
                      <div 
                        className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-muted to-background p-2"
                        style={{ display: item.poster ? 'none' : 'flex' }}
                      >
                        {item.type === 'movie' && <Film className="w-6 h-6 text-primary/50" />}
                        {item.type === 'book' && <BookOpen className="w-6 h-6 text-primary/50" />}
                        {item.type === 'web_series' && <Tv className="w-6 h-6 text-primary/50" />}
                        {item.type === 'anime' && <Sparkles className="w-6 h-6 text-primary/50" />}
                      </div>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0 py-1">
                      <div className="flex items-center gap-1.5 mb-1">
                        {item.type === 'movie' && <Film className="w-3.5 h-3.5 text-primary" />}
                        {item.type === 'book' && <BookOpen className="w-3.5 h-3.5 text-primary" />}
                        {item.type === 'web_series' && <Tv className="w-3.5 h-3.5 text-primary" />}
                        {item.type === 'anime' && <Sparkles className="w-3.5 h-3.5 text-primary" />}
                        <span className="text-xs text-muted-foreground capitalize">
                          {item.type === 'web_series' ? 'Series' : item.type}
                        </span>
                      </div>

                      <h4 className="font-medium text-sm line-clamp-2 mb-1">
                        {item.title}
                      </h4>

                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="truncate">
                          {item.type === 'book' ? item.author : item.year}
                        </span>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 text-primary fill-primary" />
                          <span>{item.rating.toFixed(1)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Remove button */}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemove(item.id);
                      }}
                      className={cn(
                        'w-8 h-8 rounded-full flex-shrink-0 self-center',
                        'opacity-0 group-hover:opacity-100',
                        'hover:bg-destructive/10 hover:text-destructive',
                        'transition-all duration-200'
                      )}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </div>
    </>
  );
}
