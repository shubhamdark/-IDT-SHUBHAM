import { Film, BookOpen, Sparkles, Heart, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface WelcomeScreenProps {
  onSuggestionClick: (suggestion: string) => void;
}

const suggestions = [
  { emoji: '😢', text: "I'm feeling a bit down today", mood: 'sad' },
  { emoji: '🎉', text: "I want something fun and uplifting!", mood: 'happy' },
  { emoji: '💭', text: "Something thought-provoking and deep", mood: 'thoughtful' },
  { emoji: '💕', text: "In the mood for romance", mood: 'romantic' },
  { emoji: '🌙', text: "Cozy comfort for a rainy night", mood: 'nostalgic' },
  { emoji: '🚀', text: "Adventure and excitement!", mood: 'adventurous' },
];

export function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 md:p-12 animate-fade-in min-h-0">
      <div className="flex flex-col items-center w-full max-w-2xl space-y-8 md:space-y-10">
        {/* Logo/Brand Section */}
        <div className="flex flex-col items-center text-center space-y-4">
          {/* Logo Icon */}
          <div className="relative w-14 h-14">
            <div className="w-14 h-14 rounded-2xl bg-gradient-amber flex items-center justify-center shadow-button">
              <Film className="w-7 h-7 text-primary-foreground" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-lg bg-card border border-border flex items-center justify-center">
              <BookOpen className="w-3.5 h-3.5 text-primary" />
            </div>
          </div>
          
          {/* Title */}
          <h1 className="font-serif text-4xl md:text-5xl font-bold text-balance">
            <span className="text-gradient-amber">Reel</span> & <span className="text-gradient-amber">Read</span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-lg text-muted-foreground max-w-md leading-relaxed px-4">
            Your personal movie buff & bookworm companion. Tell me how you're feeling, and I'll find the perfect stories for you.
          </p>
        </div>

        {/* Features Section */}
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-3 text-sm text-muted-foreground px-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
            <span>Mood-aware picks</span>
          </div>
          <div className="flex items-center gap-2">
            <MessageCircle className="w-4 h-4 text-primary flex-shrink-0" />
            <span>Natural conversation</span>
          </div>
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary flex-shrink-0" />
            <span>Save favorites</span>
          </div>
        </div>

        {/* Suggestions Section */}
        <div className="w-full flex flex-col items-center space-y-4">
          <p className="text-sm text-muted-foreground text-center">
            Try one of these to get started:
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 w-full">
            {suggestions.map((suggestion) => (
              <Button
                key={suggestion.text}
                variant="outline"
                onClick={() => onSuggestionClick(suggestion.text)}
                className="h-auto min-h-[72px] py-3 px-4 flex items-center text-left justify-start gap-3 rounded-xl border-border/50 bg-card/50 hover:bg-card hover:border-primary/30 hover:shadow-glow transition-all duration-200"
              >
                <span className="text-xl flex-shrink-0">{suggestion.emoji}</span>
                <span className="text-sm leading-tight break-words whitespace-normal flex-1">{suggestion.text}</span>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
