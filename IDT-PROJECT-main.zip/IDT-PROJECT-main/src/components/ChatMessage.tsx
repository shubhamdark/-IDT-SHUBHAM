import { Message, RecommendationItem } from '@/types/recommendation';
import { RecommendationCard } from './RecommendationCard';
import { cn } from '@/lib/utils';
import { Film, BookOpen, Sparkles } from 'lucide-react';

interface ChatMessageProps {
  message: Message;
  onItemClick: (item: RecommendationItem) => void;
  onAddToWishlist: (item: RecommendationItem) => void;
  isInWishlist: (itemId: string) => boolean;
}

export function ChatMessage({ message, onItemClick, onAddToWishlist, isInWishlist }: ChatMessageProps) {
  const isUser = message.role === 'user';

  return (
    <div
      className={cn(
        'animate-fade-up flex gap-4 px-4 py-6',
        isUser ? 'justify-end' : 'justify-start'
      )}
    >
      {!isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-amber flex items-center justify-center shadow-button">
          <Sparkles className="w-5 h-5 text-primary-foreground" />
        </div>
      )}

      <div className={cn('max-w-[85%] md:max-w-[75%]', isUser && 'order-first')}>
        <div
          className={cn(
            'rounded-2xl px-5 py-4 text-[15px] leading-relaxed',
            isUser
              ? 'bg-primary text-primary-foreground ml-auto rounded-br-md'
              : 'glass-card text-foreground rounded-bl-md'
          )}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>

        {message.recommendations && message.recommendations.length > 0 && (
          <div className="mt-6">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex gap-1.5">
                <Film className="w-4 h-4 text-primary" />
                <BookOpen className="w-4 h-4 text-primary" />
              </div>
              <span className="text-sm font-medium text-muted-foreground">
                Recommendations for you
              </span>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {message.recommendations.map((item, index) => (
                <div
                  key={item.id}
                  className="animate-fade-up"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <RecommendationCard
                    item={item}
                    onClick={() => onItemClick(item)}
                    onAddToWishlist={() => onAddToWishlist(item)}
                    isInWishlist={isInWishlist(item.id)}
                  />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {isUser && (
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
          <span className="text-sm font-medium text-secondary-foreground">You</span>
        </div>
      )}
    </div>
  );
}
