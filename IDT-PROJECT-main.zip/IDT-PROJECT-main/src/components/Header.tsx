import { Button } from '@/components/ui/button';
import { Heart, Film, BookOpen, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  wishlistCount: number;
  onWishlistClick: () => void;
  onClearChat: () => void;
  hasMessages: boolean;
}

export function Header({ wishlistCount, onWishlistClick, onClearChat, hasMessages }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-amber flex items-center justify-center shadow-sm">
              <Film className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-md bg-card border border-border flex items-center justify-center">
              <BookOpen className="w-3 h-3 text-primary" />
            </div>
          </div>
          <div className="hidden sm:block">
            <h1 className="font-serif text-xl font-bold leading-none">
              <span className="text-primary">Reel</span> & <span className="text-primary">Read</span>
            </h1>
            <p className="text-xs text-muted-foreground">Movie & Book Recommendations</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {hasMessages && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearChat}
              className="text-muted-foreground hover:text-foreground"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">New Chat</span>
            </Button>
          )}
          
          <Button
            variant="outline"
            size="sm"
            onClick={onWishlistClick}
            className={cn(
              'relative border-border/50',
              wishlistCount > 0 && 'border-primary/30'
            )}
          >
            <Heart className={cn(
              'w-4 h-4 mr-2',
              wishlistCount > 0 && 'text-primary fill-primary'
            )} />
            <span className="hidden sm:inline">Wishlist</span>
            {wishlistCount > 0 && (
              <span className="ml-2 w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </Button>
        </div>
      </div>
    </header>
  );
}
