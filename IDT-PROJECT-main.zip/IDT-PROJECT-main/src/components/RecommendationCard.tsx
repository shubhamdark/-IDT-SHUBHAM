import { RecommendationItem } from '@/types/recommendation';
import { cn } from '@/lib/utils';
import { Star, Heart, Film, BookOpen, Tv, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface RecommendationCardProps {
  item: RecommendationItem;
  onClick: () => void;
  onAddToWishlist: () => void;
  isInWishlist: boolean;
}

export function RecommendationCard({ item, onClick, onAddToWishlist, isInWishlist }: RecommendationCardProps) {
  const handleWishlistClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToWishlist();
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        'group relative cursor-pointer rounded-xl overflow-hidden',
        'bg-card border border-border/50',
        'transition-all duration-300 ease-out',
        'hover:scale-[1.02] hover:shadow-glow hover:border-primary/30'
      )}
    >
      {/* Poster */}
      <div className="aspect-[2/3] relative overflow-hidden bg-muted">
        {item.poster ? (
          <img
            src={item.poster}
            alt={item.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
              const placeholder = target.nextElementSibling as HTMLElement;
              if (placeholder) placeholder.style.display = 'flex';
            }}
          />
        ) : null}
        <div 
          className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-muted to-background p-4 text-center"
          style={{ display: item.poster ? 'none' : 'flex' }}
        >
          {item.type === 'movie' && <Film className="w-12 h-12 text-primary/50 mb-2" />}
          {item.type === 'book' && <BookOpen className="w-12 h-12 text-primary/50 mb-2" />}
          {item.type === 'web_series' && <Tv className="w-12 h-12 text-primary/50 mb-2" />}
          {item.type === 'anime' && <Sparkles className="w-12 h-12 text-primary/50 mb-2" />}
          <span className="text-xs font-medium text-muted-foreground line-clamp-3">{item.title}</span>
        </div>
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        {/* Type badge */}
        <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-1 rounded-full bg-background/80 backdrop-blur-sm text-xs font-medium">
          {item.type === 'movie' && (
            <>
              <Film className="w-3 h-3 text-primary" />
              <span>Movie</span>
            </>
          )}
          {item.type === 'book' && (
            <>
              <BookOpen className="w-3 h-3 text-primary" />
              <span>Book</span>
            </>
          )}
          {item.type === 'web_series' && (
            <>
              <Tv className="w-3 h-3 text-primary" />
              <span>Series</span>
            </>
          )}
          {item.type === 'anime' && (
            <>
              <Sparkles className="w-3 h-3 text-primary" />
              <span>Anime</span>
            </>
          )}
        </div>

        {/* Wishlist button */}
        <Button
          size="icon"
          variant="ghost"
          onClick={handleWishlistClick}
          className={cn(
            'absolute top-2 right-2 w-8 h-8 rounded-full',
            'bg-background/80 backdrop-blur-sm',
            'opacity-0 group-hover:opacity-100 transition-all duration-300',
            'hover:bg-primary hover:text-primary-foreground',
            isInWishlist && 'opacity-100 bg-primary text-primary-foreground'
          )}
        >
          <Heart className={cn('w-4 h-4', isInWishlist && 'fill-current')} />
        </Button>
      </div>

      {/* Info */}
      <div className="p-3 space-y-1.5">
        <h3 className="font-serif text-sm font-semibold line-clamp-2 leading-tight group-hover:text-primary transition-colors">
          {item.title}
        </h3>
        
        <div className="flex items-center justify-between gap-2">
          <span className="text-xs text-muted-foreground truncate">
            {item.type === 'book' ? item.author : item.year}
            {item.language && ` · ${item.language}`}
          </span>
          
          <div className="flex items-center gap-1 flex-shrink-0">
            <Star className="w-3 h-3 text-primary fill-primary" />
            <span className="text-xs font-medium">{item.rating.toFixed(1)}</span>
          </div>
        </div>

        <p className="text-xs text-muted-foreground line-clamp-1">
          {item.genre}
          {item.platform && ` · ${item.platform}`}
        </p>
      </div>
    </div>
  );
}
