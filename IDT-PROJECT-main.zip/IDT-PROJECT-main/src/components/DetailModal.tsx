import { RecommendationItem } from '@/types/recommendation';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, Film, BookOpen, Calendar, User, X, Tv, Sparkles, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DetailModalProps {
  item: RecommendationItem | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToWishlist: (item: RecommendationItem) => void;
  isInWishlist: boolean;
}

export function DetailModal({ item, isOpen, onClose, onAddToWishlist, isInWishlist }: DetailModalProps) {
  if (!item) return null;

  const genres = item.genre.split(',').map(g => g.trim());

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden bg-card border-border/50 gap-0">
        <div className="flex flex-col md:flex-row">
          {/* Poster side */}
          <div className="relative w-full md:w-1/3 aspect-[2/3] md:aspect-auto flex-shrink-0 bg-muted">
            {item.poster ? (
              <img
                src={item.poster}
                alt={item.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const placeholder = target.nextElementSibling as HTMLElement;
                  if (placeholder) placeholder.style.display = 'flex';
                }}
              />
            ) : null}
            <div 
              className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-muted to-background p-6 text-center"
              style={{ display: item.poster ? 'none' : 'flex' }}
            >
              {item.type === 'movie' && <Film className="w-16 h-16 text-primary/50 mb-3" />}
              {item.type === 'book' && <BookOpen className="w-16 h-16 text-primary/50 mb-3" />}
              {item.type === 'web_series' && <Tv className="w-16 h-16 text-primary/50 mb-3" />}
              {item.type === 'anime' && <Sparkles className="w-16 h-16 text-primary/50 mb-3" />}
              <span className="text-sm font-medium text-muted-foreground">{item.title}</span>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-card/50 hidden md:block pointer-events-none" />
          </div>

          {/* Content side */}
          <div className="flex-1 p-6 md:p-8 space-y-6">
            <DialogHeader className="space-y-4">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-2">
                  {item.type === 'movie' && <Film className="w-5 h-5 text-primary" />}
                  {item.type === 'book' && <BookOpen className="w-5 h-5 text-primary" />}
                  {item.type === 'web_series' && <Tv className="w-5 h-5 text-primary" />}
                  {item.type === 'anime' && <Sparkles className="w-5 h-5 text-primary" />}
                  <span className="text-sm font-medium text-muted-foreground capitalize">
                    {item.type === 'web_series' ? 'Series' : item.type}
                  </span>
                  {item.language && (
                    <Badge variant="outline" className="text-xs ml-2">
                      {item.language}
                    </Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="rounded-full -mt-2 -mr-2"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <DialogTitle className="font-serif text-2xl md:text-3xl font-bold leading-tight text-balance pr-8">
                {item.title}
              </DialogTitle>

              <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                {(item.type === 'movie' || item.type === 'web_series' || item.type === 'anime') && item.year && (
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4" />
                    <span>{item.year}</span>
                  </div>
                )}
                {item.type === 'book' && item.author && (
                  <div className="flex items-center gap-1.5">
                    <User className="w-4 h-4" />
                    <span>{item.author}</span>
                  </div>
                )}
                {item.platform && (
                  <div className="flex items-center gap-1.5">
                    <Globe className="w-4 h-4" />
                    <span>{item.platform}</span>
                  </div>
                )}
                <div className="flex items-center gap-1.5">
                  <Star className="w-4 h-4 text-primary fill-primary" />
                  <span className="font-medium text-foreground">{item.rating.toFixed(1)}</span>
                </div>
              </div>
            </DialogHeader>

            {/* Genres */}
            <div className="flex flex-wrap gap-2">
              {genres.map((genre) => (
                <Badge key={genre} variant="secondary" className="text-xs">
                  {genre}
                </Badge>
              ))}
            </div>

            {/* Description */}
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                Overview
              </h4>
              <p className="text-foreground/90 leading-relaxed">
                {item.overview}
              </p>
            </div>

            {/* Mood match */}
            {item.mood_match && (
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                <p className="text-sm italic text-muted-foreground">
                  "{item.mood_match}"
                </p>
              </div>
            )}

            {/* Actions */}
            <div className="pt-4 flex gap-3">
              <Button
                onClick={() => onAddToWishlist(item)}
                className={cn(
                  'flex-1',
                  isInWishlist
                    ? 'bg-primary/20 text-primary hover:bg-primary/30 border border-primary/30'
                    : 'bg-primary text-primary-foreground hover:bg-primary/90 shadow-button'
                )}
              >
                <Heart className={cn('w-4 h-4 mr-2', isInWishlist && 'fill-current')} />
                {isInWishlist ? 'In Wishlist' : 'Add to Wishlist'}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
