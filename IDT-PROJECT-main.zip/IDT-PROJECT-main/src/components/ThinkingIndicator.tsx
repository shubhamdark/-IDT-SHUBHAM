import { Sparkles } from 'lucide-react';

export function ThinkingIndicator() {
  return (
    <div className="animate-fade-up flex gap-4 px-4 py-6 justify-start">
      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-amber flex items-center justify-center shadow-button">
        <Sparkles className="w-5 h-5 text-primary-foreground" />
      </div>

      <div className="max-w-[85%] md:max-w-[75%]">
        <div className="glass-card rounded-2xl rounded-bl-md px-5 py-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Thinking</span>
            <div className="flex gap-1">
              <span 
                className="w-2 h-2 rounded-full bg-primary animate-bounce" 
                style={{ animationDelay: '0ms', animationDuration: '1s' }}
              />
              <span 
                className="w-2 h-2 rounded-full bg-primary animate-bounce" 
                style={{ animationDelay: '150ms', animationDuration: '1s' }}
              />
              <span 
                className="w-2 h-2 rounded-full bg-primary animate-bounce" 
                style={{ animationDelay: '300ms', animationDuration: '1s' }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
