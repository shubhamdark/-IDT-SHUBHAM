import { useState, useRef, useEffect } from 'react';
import { useChat } from '@/hooks/useChat';
import { useWishlist } from '@/hooks/useWishlist';
import { RecommendationItem } from '@/types/recommendation';
import { Header } from '@/components/Header';
import { WelcomeScreen } from '@/components/WelcomeScreen';
import { ChatMessage } from '@/components/ChatMessage';
import { ChatInput } from '@/components/ChatInput';
import { DetailModal } from '@/components/DetailModal';
import { WishlistPanel } from '@/components/WishlistPanel';
import { ThinkingIndicator } from '@/components/ThinkingIndicator';
import { ScrollArea } from '@/components/ui/scroll-area';

const Index = () => {
  const { messages, isLoading, sendMessage, clearMessages } = useChat();
  const { wishlist, addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const [selectedItem, setSelectedItem] = useState<RecommendationItem | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleItemClick = (item: RecommendationItem) => {
    setSelectedItem(item);
    setIsDetailOpen(true);
  };

  const handleSuggestionClick = (suggestion: string) => {
    sendMessage(suggestion);
  };

  return (
    <div className="flex flex-col h-screen bg-background film-grain">
      <Header
        wishlistCount={wishlist.length}
        onWishlistClick={() => setIsWishlistOpen(true)}
        onClearChat={clearMessages}
        hasMessages={messages.length > 0}
      />

      <main className="flex-1 flex flex-col overflow-hidden">
        {messages.length === 0 ? (
          <WelcomeScreen onSuggestionClick={handleSuggestionClick} />
        ) : (
          <ScrollArea className="flex-1 scrollbar-thin">
            <div className="max-w-4xl mx-auto py-6">
              {messages.map((message) => (
                <ChatMessage
                  key={message.id}
                  message={message}
                  onItemClick={handleItemClick}
                  onAddToWishlist={addToWishlist}
                  isInWishlist={isInWishlist}
                />
              ))}
              {isLoading && <ThinkingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
        )}

        <ChatInput
          onSend={sendMessage}
          isLoading={isLoading}
        />
      </main>

      {/* Detail Modal */}
      <DetailModal
        item={selectedItem}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
        onAddToWishlist={addToWishlist}
        isInWishlist={selectedItem ? isInWishlist(selectedItem.id) : false}
      />

      {/* Wishlist Panel */}
      <WishlistPanel
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemove={removeFromWishlist}
        onItemClick={(item) => {
          setIsWishlistOpen(false);
          handleItemClick(item);
        }}
      />
    </div>
  );
};

export default Index;
