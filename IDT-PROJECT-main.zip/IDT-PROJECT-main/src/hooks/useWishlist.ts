import { useState, useCallback, useEffect } from 'react';
import { RecommendationItem, WishlistItem } from '@/types/recommendation';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const SESSION_KEY = 'reel-read-session';

function getSessionId(): string {
  let sessionId = localStorage.getItem(SESSION_KEY);
  if (!sessionId) {
    sessionId = crypto.randomUUID();
    localStorage.setItem(SESSION_KEY, sessionId);
  }
  return sessionId;
}

export function useWishlist() {
  const [wishlist, setWishlist] = useState<WishlistItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchWishlist = useCallback(async () => {
    try {
      const sessionId = getSessionId();
      const { data, error } = await supabase
        .from('session_wishlist')
        .select('*')
        .eq('session_id', sessionId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const items: WishlistItem[] = (data || []).map(item => ({
        type: item.item_type as 'movie' | 'book',
        id: item.item_id,
        title: item.title,
        genre: item.genre || '',
        year: item.year || undefined,
        author: item.author || undefined,
        rating: Number(item.rating) || 0,
        overview: item.description || '',
        poster: item.poster_url || '',
        addedAt: new Date(item.created_at),
      }));

      setWishlist(items);
    } catch (error) {
      console.error('Failed to fetch wishlist:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWishlist();
  }, [fetchWishlist]);

  const addToWishlist = useCallback(async (item: RecommendationItem) => {
    try {
      const sessionId = getSessionId();
      
      const { error } = await supabase.from('session_wishlist').insert({
        session_id: sessionId,
        item_type: item.type,
        item_id: item.id,
        title: item.title,
        poster_url: item.poster,
        rating: item.rating,
        genre: item.genre,
        description: item.overview,
        year: item.year || null,
        author: item.author || null,
      });

      if (error) {
        if (error.code === '23505') {
          toast.info('Already in your wishlist!');
          return;
        }
        throw error;
      }

      const wishlistItem: WishlistItem = {
        ...item,
        addedAt: new Date(),
      };

      setWishlist(prev => [wishlistItem, ...prev]);
      toast.success(`Added "${item.title}" to your wishlist!`);
    } catch (error) {
      console.error('Failed to add to wishlist:', error);
      toast.error('Failed to add to wishlist');
    }
  }, []);

  const removeFromWishlist = useCallback(async (itemId: string) => {
    try {
      const sessionId = getSessionId();
      
      const { error } = await supabase
        .from('session_wishlist')
        .delete()
        .eq('session_id', sessionId)
        .eq('item_id', itemId);

      if (error) throw error;

      setWishlist(prev => prev.filter(item => item.id !== itemId));
      toast.success('Removed from wishlist');
    } catch (error) {
      console.error('Failed to remove from wishlist:', error);
      toast.error('Failed to remove from wishlist');
    }
  }, []);

  const isInWishlist = useCallback((itemId: string) => {
    return wishlist.some(item => item.id === itemId);
  }, [wishlist]);

  return {
    wishlist,
    isLoading,
    addToWishlist,
    removeFromWishlist,
    isInWishlist,
  };
}
