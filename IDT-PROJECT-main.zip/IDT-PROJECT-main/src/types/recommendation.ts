export interface RecommendationItem {
  type: 'movie' | 'book' | 'web_series' | 'anime';
  id: string;
  title: string;
  genre: string;
  year?: string;
  author?: string;
  rating: number;
  language?: string;
  platform?: string;
  overview: string;
  poster: string;
  mood_match?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  recommendations?: RecommendationItem[];
  timestamp: Date;
}

export interface WishlistItem extends RecommendationItem {
  addedAt: Date;
}
