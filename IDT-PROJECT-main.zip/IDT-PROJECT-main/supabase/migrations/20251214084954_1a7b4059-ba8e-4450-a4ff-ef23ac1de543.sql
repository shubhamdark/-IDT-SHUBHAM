-- Create wishlist table for storing user's saved movies and books
CREATE TABLE public.wishlist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users ON DELETE CASCADE,
  item_type TEXT NOT NULL CHECK (item_type IN ('movie', 'book')),
  item_id TEXT NOT NULL,
  title TEXT NOT NULL,
  poster_url TEXT,
  rating NUMERIC,
  genre TEXT,
  description TEXT,
  year TEXT,
  author TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, item_type, item_id)
);

-- Enable RLS
ALTER TABLE public.wishlist ENABLE ROW LEVEL SECURITY;

-- RLS policies for wishlist (allow public access for session-based wishlist without auth)
CREATE POLICY "Users can view their own wishlist" 
ON public.wishlist 
FOR SELECT 
USING (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can add to their own wishlist" 
ON public.wishlist 
FOR INSERT 
WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

CREATE POLICY "Users can delete from their own wishlist" 
ON public.wishlist 
FOR DELETE 
USING (auth.uid() = user_id OR user_id IS NULL);

-- Create session-based wishlist for non-authenticated users
CREATE TABLE public.session_wishlist (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id TEXT NOT NULL,
  item_type TEXT NOT NULL CHECK (item_type IN ('movie', 'book')),
  item_id TEXT NOT NULL,
  title TEXT NOT NULL,
  poster_url TEXT,
  rating NUMERIC,
  genre TEXT,
  description TEXT,
  year TEXT,
  author TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(session_id, item_type, item_id)
);

-- Enable RLS for session wishlist
ALTER TABLE public.session_wishlist ENABLE ROW LEVEL SECURITY;

-- Allow public access to session wishlist
CREATE POLICY "Public access to session wishlist" 
ON public.session_wishlist 
FOR ALL 
USING (true)
WITH CHECK (true);