-- Drop the old constraint that only allowed movie and book
ALTER TABLE public.session_wishlist 
DROP CONSTRAINT IF EXISTS session_wishlist_item_type_check;

-- Add new constraint that includes all content types
ALTER TABLE public.session_wishlist 
ADD CONSTRAINT session_wishlist_item_type_check 
CHECK (item_type = ANY (ARRAY['movie'::text, 'book'::text, 'web_series'::text, 'anime'::text]));

-- Also fix the wishlist table if it has the same constraint
ALTER TABLE public.wishlist 
DROP CONSTRAINT IF EXISTS wishlist_item_type_check;

ALTER TABLE public.wishlist 
ADD CONSTRAINT wishlist_item_type_check 
CHECK (item_type = ANY (ARRAY['movie'::text, 'book'::text, 'web_series'::text, 'anime'::text]));