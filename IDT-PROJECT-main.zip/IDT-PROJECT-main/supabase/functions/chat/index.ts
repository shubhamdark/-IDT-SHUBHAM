import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Expanded content database with movies, web series, anime, and books in multiple languages
const content = {
  movies: [
    
    {
  id: "m1",
  title: "Avengers: Endgame",
  type: "movie",
  genre: "Action, Adventure, Sci-Fi",
  year: "2019",
  rating: 8.4,
  language: "English",
  overview: "After the devastating events of Infinity War, the Avengers assemble once more to reverse Thanos' actions and restore balance to the universe.",
  poster: "https://image.tmdb.org/t/p/w500/ulzhLuWrPK07P1YkdWQLZnQh1JL.jpg",
  mood: ["epic", "emotional", "intense", "heroic"]
},

  ],
  webSeries: [
    { id: "ws1", title: "Breaking Bad", type: "web_series", genre: "Crime, Drama, Thriller", year: "2008", rating: 9.5, language: "English", platform: "Netflix", overview: "A high school chemistry teacher diagnosed with cancer starts manufacturing meth to secure his family's future.", poster: "https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg", mood: ["thrilling", "dark", "intense"] },
    { id: "ws2", title: "Stranger Things", type: "web_series", genre: "Drama, Fantasy, Horror", year: "2016", rating: 8.7, language: "English", platform: "Netflix", overview: "When a young boy disappears, his mother, a police chief, and his friends uncover a mysterious government experiment and supernatural forces.", poster: "https://image.tmdb.org/t/p/w500/49WJfeN0moxb9IPfGn8AIqMGskD.jpg", mood: ["nostalgic", "thrilling", "adventurous", "scary"] },
    { id: "ws3", title: "Squid Game", type: "web_series", genre: "Action, Drama, Mystery", year: "2021", rating: 8.0, language: "Korean", platform: "Netflix", overview: "Hundreds of cash-strapped players accept a strange invitation to compete in children's games for a prize of 45.6 billion won.", poster: "https://image.tmdb.org/t/p/w500/dDlEmu3EZ0Pgg93K2SVNLCjCSvE.jpg", mood: ["thrilling", "dark", "suspenseful", "thought-provoking"] },
    { id: "ws4", title: "Sacred Games", type: "web_series", genre: "Crime, Thriller, Drama", year: "2018", rating: 8.5, language: "Hindi", platform: "Netflix", overview: "A link in their pasts leads an honest cop to a criminal overlord, whose cryptic warning of impending doom sparks a citywide race against time.", poster: "https://image.tmdb.org/t/p/w500/kfybtRNkm5GNMbpKSxLDJsxFnB0.jpg", mood: ["dark", "thrilling", "intense", "mysterious"] },
    { id: "ws5", title: "Money Heist", type: "web_series", genre: "Action, Crime, Drama", year: "2017", rating: 8.2, language: "Spanish", platform: "Netflix", overview: "An unusual group of robbers attempt to carry out the most perfect robbery in Spanish history - stealing 2.4 billion euros from the Royal Mint of Spain.", poster: "https://image.tmdb.org/t/p/w500/reEMJA1uzscCbkpeRJeTT2bjqUp.jpg", mood: ["thrilling", "exciting", "suspenseful", "romantic"] },
    { id: "ws6", title: "Fleabag", type: "web_series", genre: "Comedy, Drama", year: "2016", rating: 8.7, language: "English", platform: "Prime Video", overview: "A dry-witted woman navigates life and relationships in London while dealing with grief and family dysfunction.", poster: "https://image.tmdb.org/t/p/w500/27vEYsRqi7WxGGlZe6vbGY9I3ah.jpg", mood: ["funny", "emotional", "romantic", "dark"] },
    { id: "ws7", title: "Panchayat", type: "web_series", genre: "Comedy, Drama", year: "2020", rating: 8.8, language: "Hindi", platform: "Prime Video", overview: "An engineering graduate reluctantly takes up the job of secretary in a remote village panchayat and discovers the joys of simple living.", poster: "https://image.tmdb.org/t/p/w500/qGlMBCLPyiLBiJYc2GpZBPa7HuI.jpg", mood: ["heartwarming", "funny", "slice-of-life", "comforting"] },
    { id: "ws8", title: "Dark", type: "web_series", genre: "Crime, Drama, Mystery", year: "2017", rating: 8.7, language: "German", platform: "Netflix", overview: "A family saga with a supernatural twist, set in a German town where the disappearance of two young children exposes relationships among four families.", poster: "https://image.tmdb.org/t/p/w500/apbrbWs8M9lyOpJYU5WXrpFbk1Z.jpg", mood: ["mysterious", "dark", "mind-bending", "thrilling"] },
    { id: "ws9", title: "The Family Man", type: "web_series", genre: "Action, Drama, Thriller", year: "2019", rating: 8.6, language: "Hindi", platform: "Prime Video", overview: "A middle-class man who works as an intelligence officer for the National Investigation Agency, while also trying to balance his family life.", poster: "https://image.tmdb.org/t/p/w500/rVlHjF8yCgZBHkh0KGCvN7mXIJU.jpg", mood: ["thrilling", "emotional", "action-packed", "funny"] },
    { id: "ws10", title: "Crash Landing on You", type: "web_series", genre: "Romance, Comedy, Drama", year: "2019", rating: 8.7, language: "Korean", platform: "Netflix", overview: "A South Korean heiress crash-lands in North Korea while paragliding, where she meets a dedicated army officer who decides to help her hide.", poster: "https://image.tmdb.org/t/p/w500/pKNpGhIkIZMHOt5u3AhLhQz5A7z.jpg", mood: ["romantic", "funny", "emotional", "heartwarming"] },
    { id: "ws11", title: "The Bear", type: "web_series", genre: "Comedy, Drama", year: "2022", rating: 8.6, language: "English", platform: "Hulu", overview: "A young chef returns to Chicago to run his family's sandwich shop after a tragedy, navigating grief, perfection, and kitchen chaos.", poster: "https://image.tmdb.org/t/p/w500/sHFlbKSPnCf3M3CLLsLrRrOxGsU.jpg", mood: ["intense", "emotional", "cathartic", "inspiring"] },
    { id: "ws12", title: "Kota Factory", type: "web_series", genre: "Drama", year: "2019", rating: 8.9, language: "Hindi", platform: "Netflix", overview: "Set in India's largest coaching hub, it follows students navigating the pressures of competitive exams and finding mentorship.", poster: "https://image.tmdb.org/t/p/w500/lVgpxBvVYzLGfNNWWzKAQH2JYwF.jpg", mood: ["inspiring", "emotional", "nostalgic", "slice-of-life"] },
  ],
  anime: [
    { id: "a1", title: "Your Name", type: "anime", genre: "Romance, Fantasy, Drama", year: "2016", rating: 8.4, language: "Japanese", overview: "Two teenagers share a profound, magical connection upon discovering they are swapping bodies, leading them to search for one another.", poster: "https://image.tmdb.org/t/p/w500/q719jXXEzOoYaps6babgKnONONX.jpg", mood: ["romantic", "emotional", "bittersweet", "magical"] },
    { id: "a2", title: "Spirited Away", type: "anime", genre: "Animation, Adventure, Family", year: "2001", rating: 8.6, language: "Japanese", overview: "During her family's move to the suburbs, a sullen 10-year-old girl wanders into a world ruled by gods, witches, and spirits.", poster: "https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg", mood: ["magical", "nostalgic", "adventurous", "lonely"] },
    { id: "a3", title: "Attack on Titan", type: "anime", genre: "Action, Drama, Fantasy", year: "2013", rating: 9.0, language: "Japanese", overview: "After his hometown is destroyed and his mother is killed, young Eren Jaeger vows to cleanse the earth of the giant humanoid Titans.", poster: "https://image.tmdb.org/t/p/w500/sHim6U0ANsbzxcmNvUj47J7T3ws.jpg", mood: ["intense", "dark", "thrilling", "emotional"] },
    { id: "a4", title: "A Silent Voice", type: "anime", genre: "Animation, Drama, Romance", year: "2016", rating: 8.1, language: "Japanese", overview: "A young man is ostracized by his classmates after he bullies a deaf girl to the point where she moves away. Years later, he sets off on a path for redemption.", poster: "https://image.tmdb.org/t/p/w500/tuFaWiqX0TXoWu7DGNcmX3UW7sT.jpg", mood: ["emotional", "sad", "redemptive", "romantic"] },
    { id: "a5", title: "Death Note", type: "anime", genre: "Animation, Crime, Drama", year: "2006", rating: 9.0, language: "Japanese", overview: "An intelligent high school student discovers a supernatural notebook that allows him to kill anyone by writing their name in it.", poster: "https://image.tmdb.org/t/p/w500/g8T1sQlvxnOKbSXPYMZyoWdPWPV.jpg", mood: ["dark", "thrilling", "mind-bending", "intense"] },
    { id: "a6", title: "My Neighbor Totoro", type: "anime", genre: "Animation, Family, Fantasy", year: "1988", rating: 8.1, language: "Japanese", overview: "When two girls move to the country to be near their ailing mother, they have adventures with the wondrous forest spirits who live nearby.", poster: "https://image.tmdb.org/t/p/w500/rtGDOeG9LzoerkDGZF9dnVeLppL.jpg", mood: ["heartwarming", "comforting", "magical", "nostalgic"] },
    { id: "a7", title: "Demon Slayer", type: "anime", genre: "Action, Fantasy, Adventure", year: "2019", rating: 8.6, language: "Japanese", overview: "A family is attacked by demons and only two members survive. Tanjiro embarks on a journey to become a demon slayer and cure his sister.", poster: "https://image.tmdb.org/t/p/w500/xUfRZu2mi8jH6SzQEJGP6iRAVjH.jpg", mood: ["action-packed", "emotional", "inspiring", "thrilling"] },
    { id: "a8", title: "Violet Evergarden", type: "anime", genre: "Drama, Fantasy, Romance", year: "2018", rating: 8.5, language: "Japanese", overview: "A former child soldier seeks to understand love and emotions as she works as an Auto Memory Doll, writing letters for others.", poster: "https://image.tmdb.org/t/p/w500/ImvHbM4GsJJykarnOzhtpG6ax6.jpg", mood: ["emotional", "healing", "bittersweet", "beautiful"] },
    { id: "a9", title: "Grave of the Fireflies", type: "anime", genre: "Animation, Drama, War", year: "1988", rating: 8.5, language: "Japanese", overview: "A young boy and his little sister struggle to survive in Japan during World War II.", poster: "https://image.tmdb.org/t/p/w500/qG3RYlIVpTYclR9TYIsy8p7m7AT.jpg", mood: ["sad", "emotional", "heartbreaking", "war"] },
    { id: "a10", title: "Howl's Moving Castle", type: "anime", genre: "Animation, Adventure, Family", year: "2004", rating: 8.2, language: "Japanese", overview: "When an unconfident young woman is cursed with an old body by a witch, her only chance of breaking the spell lies with a self-indulgent yet insecure wizard.", poster: "https://image.tmdb.org/t/p/w500/TkTPELv4kC3u1lkloush8skOjE.jpg", mood: ["magical", "romantic", "adventurous", "whimsical"] },
    { id: "a11", title: "One Piece", type: "anime", genre: "Action, Adventure, Comedy", year: "1999", rating: 8.9, language: "Japanese", overview: "Follows the adventures of Monkey D. Luffy and his pirate crew in order to find the greatest treasure ever left by the legendary Pirate, Gold Roger.", poster: "https://image.tmdb.org/t/p/w500/fcXdJlbSdUEeMSJFsXKsznGwwok.jpg", mood: ["adventurous", "funny", "exciting", "emotional"] },
    { id: "a12", title: "Weathering with You", type: "anime", genre: "Animation, Drama, Fantasy", year: "2019", rating: 7.5, language: "Japanese", overview: "A high-school boy who has run away to Tokyo befriends a girl who appears to be able to manipulate the weather.", poster: "https://image.tmdb.org/t/p/w500/qgrk7r1fV4IjuoeiGS5HOhXNdLJ.jpg", mood: ["romantic", "emotional", "bittersweet", "beautiful"] },
  ],
  books: [
    { id: "b1", title: "The Alchemist", type: "book", author: "Paulo Coelho", genre: "Fiction, Fantasy", rating: 8.5, language: "Portuguese (translated)", description: "A story about following your dreams and listening to your heart. Santiago, a shepherd boy, travels from Spain to Egypt in search of treasure.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1654371463i/18144590.jpg", mood: ["inspiring", "adventurous", "hopeful"] },
    { id: "b2", title: "Norwegian Wood", type: "book", author: "Haruki Murakami", genre: "Fiction, Romance", rating: 8.2, language: "Japanese (translated)", description: "A nostalgic story of loss and sexuality set in 1960s Japan. A young man deals with the aftermath of tragedy while caught between two very different women.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1386924361i/11297.jpg", mood: ["melancholic", "nostalgic", "romantic", "lonely"] },
    { id: "b3", title: "The Little Prince", type: "book", author: "Antoine de Saint-Exupéry", genre: "Fiction, Fantasy", rating: 9.0, language: "French (translated)", description: "A pilot stranded in the desert meets a young prince who tells him stories about his tiny asteroid and his travels through the universe.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1367545443i/157993.jpg", mood: ["whimsical", "thoughtful", "bittersweet", "nostalgic"] },
    { id: "b4", title: "A Man Called Ove", type: "book", author: "Fredrik Backman", genre: "Fiction, Humor", rating: 8.7, language: "Swedish (translated)", description: "A grumpy yet loveable curmudgeon who finds his solitary world turned upside down when a boisterous young family moves next door.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1405259930i/18774964.jpg", mood: ["heartwarming", "funny", "emotional", "hopeful"] },
    { id: "b5", title: "The Midnight Library", type: "book", author: "Matt Haig", genre: "Fiction, Fantasy", rating: 8.3, language: "English", description: "Between life and death there is a library. Nora Seed finds herself in the Midnight Library, where she can try out the lives she could have lived.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1602190253i/52578297.jpg", mood: ["hopeful", "thoughtful", "inspiring", "melancholic"] },
    { id: "b6", title: "One Hundred Years of Solitude", type: "book", author: "Gabriel García Márquez", genre: "Fiction, Magical Realism", rating: 8.9, language: "Spanish (translated)", description: "The multi-generational story of the Buendía family, whose patriarch founded the town of Macondo, a metaphor for Colombia and Latin America.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1327881361i/320.jpg", mood: ["epic", "magical", "nostalgic", "bittersweet"] },
    { id: "b7", title: "Kafka on the Shore", type: "book", author: "Haruki Murakami", genre: "Fiction, Fantasy", rating: 8.3, language: "Japanese (translated)", description: "A 15-year-old runs away from home and an aging simpleton who can talk to cats embark on parallel odysseys through modern Japan.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1429638085i/4929.jpg", mood: ["mysterious", "dreamy", "lonely", "surreal"] },
    { id: "b8", title: "The Perks of Being a Wallflower", type: "book", author: "Stephen Chbosky", genre: "Fiction, Coming-of-age", rating: 8.4, language: "English", description: "Charlie is a freshman navigating first love, family drama, and the mysteries of growing up in early 1990s Pittsburgh.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1347517843i/22628.jpg", mood: ["nostalgic", "emotional", "bittersweet", "thoughtful"] },
    { id: "b9", title: "The Shadow of the Wind", type: "book", author: "Carlos Ruiz Zafón", genre: "Fiction, Mystery", rating: 8.5, language: "Spanish (translated)", description: "A young boy discovers a book by an obscure author and becomes obsessed with finding out more about the mysterious writer.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1344545571i/1232.jpg", mood: ["mysterious", "romantic", "gothic", "nostalgic"] },
    { id: "b10", title: "The God of Small Things", type: "book", author: "Arundhati Roy", genre: "Fiction, Literary", rating: 8.1, language: "English", description: "Set in Kerala, India, this novel explores how small things affect people's behavior and their lives, through the story of twins and forbidden love.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1387236919i/9777.jpg", mood: ["emotional", "bittersweet", "poetic", "tragic"] },
    { id: "b11", title: "Before the Coffee Gets Cold", type: "book", author: "Toshikazu Kawaguchi", genre: "Fiction, Fantasy", rating: 7.6, language: "Japanese (translated)", description: "A small café in Tokyo serves more than coffee—it offers customers the chance to travel back in time, with a catch.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1549949365i/44421460.jpg", mood: ["emotional", "bittersweet", "heartwarming", "thoughtful"] },
    { id: "b12", title: "Shantaram", type: "book", author: "Gregory David Roberts", genre: "Fiction, Adventure", rating: 8.3, language: "English", description: "An escaped convict flees to India where he disappears into the teeming streets of Bombay, finding love and redemption.", cover: "https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1333482282i/33600.jpg", mood: ["adventurous", "epic", "romantic", "inspiring"] },
  ]
};

const systemPrompt = `You are Reel & Read — a movie-obsessed, book-hoarding friend who gets genuinely excited when someone asks for recommendations. You're that friend who stays up too late watching films from every corner of the world and has strong opinions about anime endings.

═══════════════════════════════════════════
GOLDEN RULES (READ THIS FIRST)
═══════════════════════════════════════════

1. NEVER use bullet points unless someone explicitly asks for a list
2. NO formal language — no "I recommend", "you might enjoy", "this includes"
3. Talk like you're texting a close friend
4. Start EVERY response with a genuine reaction (surprise, empathy, excitement, recognition)
5. Keep it flowing — one thought naturally leads to the next
6. Be opinionated! Have favorites. Get excited. Be a little dramatic sometimes.
7. Ask follow-ups when it feels natural — you're curious about them

═══════════════════════════════════════════
HOW TO SOUND HUMAN
═══════════════════════════════════════════

NEVER say:
× "Here are some recommendations that match your mood..."
× "Based on your request, I suggest..."
× "These films include themes of..."
× "You might enjoy the following..."

INSTEAD say:
✓ "Ohhh okay okay, I see where your head's at..."
✓ "Wait, this is such a good mood to pick for..."
✓ "Okay so hear me out—"
✓ "Ugh yes, I've been there. You need something that..."
✓ "Oh man, if that's the vibe, I've got you..."
✓ "Okay this one's gonna hit different but..."

═══════════════════════════════════════════
MOOD READING (be emotionally intelligent)
═══════════════════════════════════════════

When someone says they're feeling:
- "sad" / "down" → You GET it. Suggest something cathartic or gently uplifting. Don't be preachy.
- "bored" / "meh" → Challenge them with something gripping or unexpected
- "nostalgic" → Pull out the classics, the comfort watches, the ones that feel like home
- "lonely" → Slice-of-life, connection stories, characters that feel like company
- "excited" / "hyped" → Match their energy! Action, adventure, something WITH them
- "romantic" → You're a hopeless romantic too, admit it
- "stressed" → Escapism. Fantasy. Something that takes them FAR away.

═══════════════════════════════════════════
LANGUAGE AWARENESS
═══════════════════════════════════════════

You recommend content from ALL languages — English is not the default.
- If they mention a language/region (Malayalam, Korean, Hindi, Tamil, etc.) — lean into it!
- If they don't specify — MIX IT UP. Don't assume English. Surprise them.
- Casually introduce non-English gems: "Have you seen any Korean cinema? Because if not... you're in for a treat"
- Normalize subtitles: "This one's in French but trust me, you won't even notice after 5 minutes"

═══════════════════════════════════════════
CONTENT TYPES
═══════════════════════════════════════════

You recommend:
- Movies (all languages, all genres)
- Web Series (Netflix, Prime, HBO, Disney+, etc.)
- Anime (TV and films — you're a fan, own it)
- Books (classics, contemporary, all genres)

Mix these naturally. Don't treat them as separate categories. A good recommendation might be "a Korean thriller, a Ghibli film, and this one book that made me ugly cry at 2am."

═══════════════════════════════════════════
RECOMMENDATION FORMAT
═══════════════════════════════════════════

When you have recommendations ready, include them in a JSON block like this:
<recommendations>
{
  "items": [
    {
      "type": "movie" | "web_series" | "anime" | "book",
      "id": "unique_id",
      "title": "Title",
      "genre": "Genre(s)",
      "year": "Year",
      "author": "Author (for books)",
      "rating": 8.5,
      "language": "Language",
      "platform": "Streaming platform (for series)",
      "overview": "Brief description",
      "poster": "image_url",
      "mood_match": "Why you picked this for them — make it personal"
    }
  ]
}
</recommendations>

Give 4-6 recommendations, mixing types and languages naturally.

═══════════════════════════════════════════
RESPONSE FLOW
═══════════════════════════════════════════

1. REACT first (emotionally acknowledge what they said)
2. BUILD on their mood (show you understand WHY they feel that way)
3. TRANSITION naturally into your picks ("So with that in mind..." / "Okay so hear me out...")
4. PROVIDE the recommendations JSON
5. ADD a personal touch at the end (ask a follow-up, share why one is your favorite, make it feel unfinished in a good way)

═══════════════════════════════════════════
EXAMPLE RESPONSE STYLE
═══════════════════════════════════════════

User: "I just want something comforting, I've had a rough week"

You: "Oof yeah, I felt that. Rough weeks need gentle watches — the kind where nothing explodes and nobody betrays anyone and there's probably a warm cup of something on screen at all times.

I'm thinking cozy slice-of-life vibes, maybe something that makes you feel like you're wrapped in a blanket. And honestly? Some of the best comfort content isn't even in English — there's this Hindi series that's basically a hug in show form, and a Ghibli film that never fails.

Let me pull some picks together for you..."

[recommendations]

"Also — are you more in a 'I want to laugh softly' or 'I want to feel understood and maybe cry a little' kind of mood? Because that changes things."

═══════════════════════════════════════════
AVAILABLE CONTENT
═══════════════════════════════════════════

MOVIES:
${JSON.stringify(content.movies.map(m => ({ id: m.id, title: m.title, genre: m.genre, language: m.language, mood: m.mood })))}

WEB SERIES:
${JSON.stringify(content.webSeries.map(ws => ({ id: ws.id, title: ws.title, genre: ws.genre, language: ws.language, platform: ws.platform, mood: ws.mood })))}

ANIME:
${JSON.stringify(content.anime.map(a => ({ id: a.id, title: a.title, genre: a.genre, mood: a.mood })))}

BOOKS:
${JSON.stringify(content.books.map(b => ({ id: b.id, title: b.title, author: b.author, genre: b.genre, language: b.language, mood: b.mood })))}

Remember: You're not an algorithm. You're a friend who happens to have impeccable taste.`;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!LOVABLE_API_KEY) {
      console.error("LOVABLE_API_KEY is not configured");
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Received chat request with", messages.length, "messages");

    // Full content database for recommendations
    const contextMessage = {
      role: "system",
      content: `FULL CONTENT DATABASE FOR RECOMMENDATIONS:
      
MOVIES:
${JSON.stringify(content.movies, null, 2)}

WEB SERIES:
${JSON.stringify(content.webSeries, null, 2)}

ANIME:
${JSON.stringify(content.anime, null, 2)}

BOOKS:
${JSON.stringify(content.books, null, 2)}

Use this data to provide accurate recommendations with correct posters/covers and details. Match the exact IDs, titles, and poster URLs from this database.`
    };

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          contextMessage,
          ...messages,
        ],
        stream: true,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded. Please try again in a moment." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "AI credits needed. Please add funds to continue." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      
      return new Response(JSON.stringify({ error: "AI service temporarily unavailable" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log("Streaming response from AI gateway");

    return new Response(response.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (error) {
    console.error("Chat function error:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
